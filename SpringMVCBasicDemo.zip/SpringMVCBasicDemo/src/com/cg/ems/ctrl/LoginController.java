package com.cg.ems.ctrl;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.ems.dto.Login;
import com.cg.ems.dto.RegisterDto;
import com.cg.ems.service.LoginService;

@Controller
public class LoginController 
{
	@Autowired
	LoginService logSer;
	
	public LoginService getLogSer() 
	{
		return logSer;
	}

	public void setLogSer(LoginService logSer) 
	{
		this.logSer = logSer;
	}
	
	/*******************ShowLoginPage********************************************/

	@RequestMapping(value="/ShowLoginPage")
	public String dispLoginPage(Model model)
	{
		Login lgg = new Login();
		lgg.setUserName("Enter UR USER ID HERE");
		model.addAttribute("log",lgg);
		return "Login";
	}
	
	@RequestMapping(value="/ValidateUser")
	public String validateUser(@ModelAttribute("log") @Valid Login lgg,BindingResult result,Model model)
	{
		if(result.hasErrors())
		{
			return "Login";
		}
		else
		{
			System.out.println("user entered : "+lgg);
			
			if(logSer.validateUser(lgg))
			{
				return "Success";
			}
			else
			{
				model.addAttribute("MsgObj","Please Check UR Password");
				return "Login";
			}			
		}
	}
	
	
	/*****************************ShowRegisterpage*********************************/
	
	@RequestMapping(value="/ShowRegisterPage")
	public String dispRegisterPage(Model model)
	{
		RegisterDto reg = new RegisterDto();
		
		ArrayList<String> cityList = new ArrayList<String>();
		cityList.add("Pune");
		cityList.add("Noida");
		cityList.add("Mumbai");
		cityList.add("Delhi");
		model.addAttribute("cityListObj",cityList);
		
		ArrayList<String> skillList = new ArrayList<String>();
		skillList.add("Java");
		skillList.add("HTML");
		skillList.add("Oracle");
		skillList.add("BI");
		skillList.add("Testing");
		model.addAttribute("skillListObj",skillList);
		
		model.addAttribute("regObj",reg);
		
		return "Register";
	}
	
	/*************************AddUserDetails.obj******************************************/
	
	@RequestMapping(value="/AddUserDetails")
	public String insertUserDetails(@ModelAttribute("regObj") RegisterDto reg, BindingResult result, Model model)
	{
		Login log = new Login(reg.getUname(), reg.getPwd());
		logSer.addUser(log);
		logSer.addUserDetails(reg);
		return "ListAllUser";
	}

}

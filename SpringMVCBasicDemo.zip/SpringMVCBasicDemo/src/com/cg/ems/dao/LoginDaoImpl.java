package com.cg.ems.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Component;

import com.cg.ems.dto.Login;
import com.cg.ems.dto.RegisterDto;

@Component
@Transactional
public class LoginDaoImpl implements LoginDao
{
    @PersistenceContext
    EntityManager em;
    @Override
	public Login getUserById(String unm) 
	{
		//Login userDetails = new Login("amit@gmail.com","amit");
    	
    	System.out.println("In Logindao getUserBYId");
    	Login user = em.find(Login.class, unm);
    	System.out.println("abvjygjhg"+user);
		return user;
	}
	@Override
	public RegisterDto addUserDetails(RegisterDto userDetails) 
	{
		em.persist(userDetails);
		RegisterDto reg = em.find(RegisterDto.class, userDetails.getUname());
		return reg;
	}
	@Override
	public ArrayList<RegisterDto> getAllUserDetails() 
	{
		String selectUserQry = "SELECT reg from RegisterDto reg";
		return null;
	}
	@Override
	public Login addUser(Login user) 
	{
		em.persist(user);
		Login uu = em.find(Login.class, user.getUserName());
		return uu;
		
	}
	

}
